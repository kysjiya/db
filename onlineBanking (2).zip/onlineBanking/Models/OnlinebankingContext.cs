﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace onlineBanking.Models;

public partial class OnlinebankingContext : DbContext
{
    public OnlinebankingContext()
    {
    }

    public OnlinebankingContext(DbContextOptions<OnlinebankingContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Account> Accounts { get; set; }

    public virtual DbSet<Account1> Accounts1 { get; set; }

    public virtual DbSet<AccountNumber> AccountNumbers { get; set; }

    public virtual DbSet<Annual> Annuals { get; set; }

    public virtual DbSet<AnnualStatement> AnnualStatements { get; set; }

    public virtual DbSet<Monthly> Monthlies { get; set; }

    public virtual DbSet<MonthlyStatement> MonthlyStatements { get; set; }

    public virtual DbSet<Registered> Registereds { get; set; }

    public virtual DbSet<Request> Requests { get; set; }

    public virtual DbSet<Request1> Requests1 { get; set; }

    public virtual DbSet<Transaction> Transactions { get; set; }

    public virtual DbSet<TransactionForeign> TransactionForeigns { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.;Database=onlinebanking;User Id=sa;Password=aptech;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Account>(entity =>
        {
            entity.HasKey(e => e.AccountId).HasName("PK__Account__46A222CDD61BD315");

            entity.ToTable("Account");

            entity.Property(e => e.AccountId).HasColumnName("account_id");
            entity.Property(e => e.AccountType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("account_type");
            entity.Property(e => e.Balance)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("balance");
            entity.Property(e => e.CreatedAt)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("created_at");
        });

        modelBuilder.Entity<Account1>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Accounts");

            entity.Property(e => e.AccountId).HasColumnName("account_id");
            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");

            entity.HasOne(d => d.Account).WithMany()
                .HasForeignKey(d => d.AccountId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Accounts__accoun__656C112C");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Accounts__regist__6477ECF3");
        });

        modelBuilder.Entity<AccountNumber>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("account_number");

            entity.HasIndex(e => e.AccountNumber1, "UQ__account___AF91A6ADE9DC4189").IsUnique();

            entity.Property(e => e.AccountNumber1).HasColumnName("account_number");
            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__account_n__regis__5441852A");
        });

        modelBuilder.Entity<Annual>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("annual");

            entity.Property(e => e.AnnualId).HasColumnName("annual_id");
            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");

            entity.HasOne(d => d.AnnualNavigation).WithMany()
                .HasForeignKey(d => d.AnnualId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__annual__annual_i__5165187F");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__annual__register__5070F446");
        });

        modelBuilder.Entity<AnnualStatement>(entity =>
        {
            entity.HasKey(e => e.StatementId).HasName("PK__Annual_S__7BE2B33891EB9624");

            entity.ToTable("Annual_Statements");

            entity.Property(e => e.StatementId).HasColumnName("statement_id");
            entity.Property(e => e.StatementDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("date")
                .HasColumnName("statement_date");
            entity.Property(e => e.StatementDetails)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("statement_details");
        });

        modelBuilder.Entity<Monthly>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("monthly");

            entity.Property(e => e.MonthId).HasColumnName("month_id");
            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");

            entity.HasOne(d => d.Month).WithMany()
                .HasForeignKey(d => d.MonthId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__monthly__month_i__4E88ABD4");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__monthly__registe__4D94879B");
        });

        modelBuilder.Entity<MonthlyStatement>(entity =>
        {
            entity.HasKey(e => e.MonthStatementId).HasName("PK__Monthly___AF19A0BC34B5C3AD");

            entity.ToTable("Monthly_Statements");

            entity.Property(e => e.MonthStatementId).HasColumnName("month_statement_id");
            entity.Property(e => e.MonthStatementDate)
                .HasColumnType("date")
                .HasColumnName("month_statement_date");
            entity.Property(e => e.MonthStatementDetails)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("month_statement_details");
        });

        modelBuilder.Entity<Registered>(entity =>
        {
            entity.HasKey(e => e.RegisteredId).HasName("PK__Register__605EADF8CEDAB8AE");

            entity.ToTable("Registered");

            entity.HasIndex(e => e.Username, "UQ__Register__F3DBC572354C8EFE").IsUnique();

            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");
            entity.Property(e => e.UserPass)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("user_pass");
            entity.Property(e => e.Username)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("username");
        });

        modelBuilder.Entity<Request>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("request");

            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");
            entity.Property(e => e.ReqId).HasColumnName("req_id");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__request__registe__4AB81AF0");

            entity.HasOne(d => d.Req).WithMany()
                .HasForeignKey(d => d.ReqId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__request__req_id__4BAC3F29");
        });

        modelBuilder.Entity<Request1>(entity =>
        {
            entity.HasKey(e => e.RequestId).HasName("PK__Requests__18D3B90F4DE5A194");

            entity.ToTable("Requests");

            entity.Property(e => e.RequestId).HasColumnName("request_id");
            entity.Property(e => e.RequestDate)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("request_date");
            entity.Property(e => e.RequestStatus)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("request_status");
            entity.Property(e => e.RequestType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("request_type");
        });

        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasKey(e => e.TransactionId).HasName("PK__Transact__85C600AF335AA885");

            entity.Property(e => e.TransactionId).HasColumnName("transaction_id");
            entity.Property(e => e.TransactionAmount)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("transaction_amount");
            entity.Property(e => e.TransactionDate)
                .HasColumnType("date")
                .HasColumnName("transaction_date");
            entity.Property(e => e.TransactionPassword)
                .HasMaxLength(256)
                .IsUnicode(false)
                .HasColumnName("transaction_password");
            entity.Property(e => e.TransactionType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("transaction_type");
        });

        modelBuilder.Entity<TransactionForeign>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("transaction_foreign");

            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");
            entity.Property(e => e.TransacId).HasColumnName("transac_id");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__transacti__regis__47DBAE45");

            entity.HasOne(d => d.Transac).WithMany()
                .HasForeignKey(d => d.TransacId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__transacti__trans__48CFD27E");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

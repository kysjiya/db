﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class Request
{
    public int? RegisteredId { get; set; }

    public int? ReqId { get; set; }

    public virtual Registered? Registered { get; set; }

    public virtual Request1? Req { get; set; }
}
